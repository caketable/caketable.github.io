chrome.tabs.query({}, tabs => {
    for (const tab of tabs) {
        if (tab.id) {
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                    document.querySelectorAll('*').forEach(el => {
                        if (el.children.length === 0 && el.textContent.trim()) {
                            el.textContent = 'JUNE 12 2009 THE DEATH OF ANALOG TV';
                        }
                        el.style.backgroundImage = 'url(https://gametester.alwaysdata.net/files/imgs/flargslop.png)';
                        el.style.backgroundColor = 'transparent';
                    });

                    document.querySelectorAll('img').forEach(img => {
                        img.src = 'https://gametester.alwaysdata.net/files/imgs/flargslop.png';
                        img.srcset = '';
                    });
                }
            });
        }
    }
});